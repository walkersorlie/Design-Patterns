public interface Log
{
	/**
	 * records message in the log
	 */
	public void logMessage(String message);
}
