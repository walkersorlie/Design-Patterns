
public class TemplateTester {
	public static void main(String[] args) {
		AbstractTemplate temp = new ConcreteTemplate();
		temp.templateMethod();
	}
}
