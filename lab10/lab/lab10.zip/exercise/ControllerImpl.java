package exercise;

public class ControllerImpl implements Controller {

    public void processModel(Model model, String input) {
        model.process(input);
    }

}
