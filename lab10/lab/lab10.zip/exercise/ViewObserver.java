package exercise;


public interface ViewObserver
{
  public void updateView(String message);
}