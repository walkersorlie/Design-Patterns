package exercise;

public interface View  {
    public void display(String s);
    public void createView();
}