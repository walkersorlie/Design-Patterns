public interface RandomSequence {
  public int getNext();
}
