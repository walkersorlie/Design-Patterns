/**
 * A class representing a Tea.
 */

public class Tea {
	private String flavor; // i.e. "Earl Grey", "English Breakfast"
	
	public Tea(String flavor) {
		this.flavor = flavor;
	}
	
	public String getflavor() {
		return flavor;
	}

}
